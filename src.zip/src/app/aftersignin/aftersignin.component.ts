import { Component, OnInit } from '@angular/core';
import {   Employee } from '../employee';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-aftersignin',
  templateUrl: './aftersignin.component.html',
  styleUrls: ['./aftersignin.component.css']
})
export class AftersigninComponent implements OnInit {
user:Employee=new Employee();
username:string;
  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
  	this.username=this.route.snapshot.params['username'];
  }

}
