export class Employee {
	empid: number;
	name: string;
	password: string;
	address: string;
	email: string;
	phone: string;
}
