package project.maven.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import project.maven.model.Login;
import project.maven.model.User;

public class UserDaoImpl implements UserDao {
	
	 @Autowired
	  DataSource datasource;
	  @Autowired
	  JdbcTemplate jdbcTemplate;
	  public int register(User user) {
	    String sql = "insert into employee(name,password,address,email,phone) values(?,?,?,?,?)";
	    return jdbcTemplate.update(sql, new Object[] { user.getName(), user.getPassword(),  user.getAddress(), user.getEmail(), user.getPhone() });
	    }
	    public User validateUser(Login login) {
	    String sql = "select * from employee where name='" + login.getName() + "' and password='" + login.getPassword()
	    + "'";
	    List<User> users = jdbcTemplate.query(sql,new UserMapper());
	    return users.size() > 0 ? users.get(0) : null;
	    }
	  }
	  class UserMapper implements RowMapper<User> {
	  public User mapRow(ResultSet rs, int arg1) throws SQLException {
	    User user = new User();
	    user.setName(rs.getString("name"));
	    user.setPassword(rs.getString("password"));
	    user.setAddress(rs.getString("address"));
	    user.setEmail(rs.getString("email"));
	    user.setPhone(rs.getString("phone"));
	    return user;
	  }

}
