package project.maven.dao;

import project.maven.model.Login;
import project.maven.model.User;

public interface UserDao {
	 int register(User user);
	  User validateUser(Login login);
}
