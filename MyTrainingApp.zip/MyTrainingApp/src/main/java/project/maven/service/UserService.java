package project.maven.service;

import project.maven.model.Login;
import project.maven.model.User;

public interface UserService {
	int register(User user);

	  User validateUser(Login login);
}
