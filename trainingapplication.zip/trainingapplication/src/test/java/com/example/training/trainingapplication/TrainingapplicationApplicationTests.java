package com.example.training.trainingapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainingapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
