package com.example.training.trainingapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingapplicationApplication.class, args);
	}

}
