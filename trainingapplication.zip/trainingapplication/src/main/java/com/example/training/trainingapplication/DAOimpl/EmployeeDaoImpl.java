package com.example.training.trainingapplication.DAOimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import com.example.training.trainingapplication.DAO.EmployeeDAO;
import com.example.training.trainingapplication.model.Employee;
import com.example.training.trainingapplication.util.DButil;



@RestController
public class EmployeeDaoImpl implements EmployeeDAO {
	static List<Employee> list1=new ArrayList();
	Connection connection;
	
	public EmployeeDaoImpl() {
		connection = DButil.getConnection();
		System.out.println("connection" + connection);
	}
	public List<Employee> viewAllEmployee(){
		//List<Customer> customer = new ArrayList<Customer>();		
		System.out.println("Inside viewAll employees");

		try {
			list1.clear();

			System.out.println("Inside try");
			PreparedStatement stmt = connection.prepareStatement("select * from employee");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				Employee emp=new Employee();
				System.out.println("Inside while");
				emp.setEmpid(rs.getInt("empid"));
				emp.setName(rs.getString("name"));
				emp.setPassword(rs.getString("password"));
				emp.setAddress(rs.getString("address"));
				emp.setEmail(rs.getString("email"));
				emp.setPhone(rs.getString("phone"));

				System.out.println("Inside while-2");
				list1.add(emp);
				System.out.println(list1);	
			}
			}catch(Exception e) {}
		return list1;
	}
	public Employee createEmployee(Employee employee) {
		int noOfRecords=0;
		try {
		PreparedStatement pst = connection.prepareStatement("Insert into employee(name,password,address,email,phone) values(?,?,?,?,?)");
		pst.setString(1,employee.getName());
		System.out.println("after active");
		pst.setString(2,employee.getPassword());
		pst.setString(3,employee.getAddress());
		pst.setString(4,employee.getEmail());
		pst.setString(5,employee.getPhone());

		noOfRecords=pst.executeUpdate();
		
		System.out.println(noOfRecords + "record inserted successfully");
		}catch(Exception e) {}
		return employee;
	}
	
	@Override
	public int loginValidation(String name,String password){
		int flag=0;
		for (Employee c:list1) {
			System.out.println("Employee data----"+c);
			if (c.getName().equals(name)  && c.getPassword().equals(password)) {
				flag=1;							
				//return flag;
			} 
		}
		System.out.println("flag"+flag);
		return flag;
	}

}
