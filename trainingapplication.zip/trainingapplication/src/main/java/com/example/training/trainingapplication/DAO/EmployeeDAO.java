package com.example.training.trainingapplication.DAO;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import com.example.training.trainingapplication.model.Employee;

@RestController
public interface EmployeeDAO {

	public List<Employee> viewAllEmployee();
	public Employee createEmployee(Employee employee);
	public int loginValidation(String name,String password);

}
