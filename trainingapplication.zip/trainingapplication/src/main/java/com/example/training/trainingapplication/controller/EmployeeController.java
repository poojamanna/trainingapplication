package com.example.training.trainingapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.training.trainingapplication.DAO.EmployeeDAO;
import com.example.training.trainingapplication.model.Employee;



@CrossOrigin(origins = "http://localhost:4200")
@RestController

public class EmployeeController {
	@Autowired
	private EmployeeDAO employeeDAO;
	
	@GetMapping("/employee")
	public List getEmployee() {	
	return employeeDAO.viewAllEmployee();
}
	
	@GetMapping("/employee/{name}/{password}")
	public ResponseEntity getEmployeeLogin(@PathVariable("name") String name,@PathVariable("password") String password) {		
		int flag=employeeDAO.loginValidation(name,password);			
		if (flag == 0) {
			return new ResponseEntity("No Employee found for ID " + name, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(flag, HttpStatus.OK);
	}
	
	@PostMapping("/employee")
	public ResponseEntity createEmployee(@RequestBody Employee employee) {
		employeeDAO.createEmployee(employee);
		System.out.println("hkajh");
		return new ResponseEntity(employee, HttpStatus.OK);
	}


}
